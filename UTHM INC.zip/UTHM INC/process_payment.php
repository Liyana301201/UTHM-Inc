<?php
// Database connection settings
$servername = "127.0.0.1";
$username = "u489039624_G10";
$password = "webBIT21503";
$dbname = "u489039624_G10";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process the form data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $paymentType = $_POST['payment-method'];
    $details = '';

    switch ($paymentType) {
        case 'cod':
            $details = json_encode([
                'card_number' => $_POST['card-number'] ?? '',
                'expiration' => $_POST['card-expiration'] ?? '',
                'cvv' => $_POST['card-cvv'] ?? ''
            ]);
            break;
        case 'banking':
            $details = $_POST['bank'] ?? '';
            break;
        case 'ewallet':
            $details = $_POST['payment'] ?? '';
            break;
        case 'qr':
            $details = 'QR Payment';
            break;
    }

    // Insert data into database
    $stmt = $conn->prepare("INSERT INTO payments (payment_type, details) VALUES (?, ?)");
    $stmt->bind_param("ss", $paymentType, $details);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "Payment method saved successfully!";
    } else {
        echo "Error saving payment method.";
    }
    $stmt->close();
}
$conn->close();
?>
