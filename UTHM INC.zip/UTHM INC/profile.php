<?php
// Database connection settings
$servername = "127.0.0.1";
$username = "u489039624_G10";
$password = "webBIT21503";
$dbname = "u489039624_G10";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $phone_number = $_POST['phone_number'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password
    $gender = $_POST['gender'];
    $day = $_POST['day'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    $date_of_birth = $year . '-' . $month . '-' . $day;

    // Handle file upload
    if (isset($_FILES['profilePicture']) && $_FILES['profilePicture']['error'] == 0) {
        $profilePicture = $_FILES['profilePicture']['name'];
        $target_directory = "uploads/";
        
        // Ensure the uploads directory exists
        if (!is_dir($target_directory)) {
            mkdir($target_directory, 0777, true);
        }

        $target_file = $target_directory . basename($profilePicture);

        // Move the uploaded file to the target directory
        if (move_uploaded_file($_FILES['profilePicture']['tmp_name'], $target_file)) {
            // File successfully uploaded
        } else {
            echo "Error uploading file.";
            exit();
        }
    } else {
        $profilePicture = null;
    }

    // Insert data into database
    $sql = "INSERT INTO profiles (name, email, username, phone_number, password, gender, date_of_birth, profile_picture)
            VALUES ('$name', '$email', '$username', '$phone_number', '$password', '$gender', '$date_of_birth', '$target_file')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
