<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UTHM INC</title>
    <link rel="icon" type="image/png" href="logo2.png">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .navbar {
            background-color: #ffffff;
            padding: 10px;
            text-align: center;
        }

        .dropbtn {
            background-color: transparent; /* Transparent background */
            padding: 16px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            outline: none;
        }

        .dropbtn i {
            color: white; /* White color for the icon */
        }

        .profile-icon {
            border-radius: 50%; /* Circular profile icon */
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown:hover .dropbtn {
            background-color: #f8f8f8;
        }

        </style>
</head>


<body>
   <!-- Header design from Alibaba.com website -->
   <header class="upper-header">
        <div class="upper-header-content">
            <div class="left-section">
                <div class="logo">
                    <img src="logo.png" alt="Logo">
                    <span>UTHM INC</span>
                </div>
            </div>
            <div class="right-section">
                <a href="index.php" class="icon-link"><i class="fas fa-home"></i></a>
                <a href="#" class="icon-link"><i class="fas fa-shop"></i></a>
                <a href="cart.html" class="icon-link"><i class="fas fa-cart-shopping"></i></a>
                <a href="#" class="icon-link"><i class="fas fa-headset"></i></a>
                <!-- Dropdown for user profile -->
                <div class="dropdown">
                    <button class="dropbtn"><i class="fas fa-user"></i></button>
                    <div class="dropdown-content">
                        <a href="profile.html">Account</a>
                        <a href="address detail.html">Address</a>
                        <a href="payment.html">Payment</a>
                    </div>
                </div>
            </div>
        </div>

        <a href="signup.php" class="sign-up-btn">Sign up</a>
    </div>
</div>

    </header>
    <header class="lower-header">
        <div class="lower-header-content">
            <nav class="nav-links">
                <a href="#"><i class="fas fa-bars"></i> Categories</a>
                <a href="#"><i class="fas fa-mobile-phone"></i> Get the app</a>
            </nav>
        </div>
    </header>

    <div class="modal" id="welcome-modal">
        <div class="modal-content">
            <span class="close-button">&times;</span>
            <h2>Welcome to BookMate!</h2>
            <p>We are excited to have you back. Check out our latest promotions and new arrivals!</p>
            <div class="modal-buttons">
                <a href="promotions.html" class="promo-btn">View Promotions</a>
                <a href="new-arrivals.html" class="new-arrivals-btn">New Arrivals</a>
            </div>
        </div>
    </div>

    <script>
        function signOut() {
            
            localStorage.removeItem('userSession');
           
            window.location.href = 'signin.php';
        }

        document.addEventListener('DOMContentLoaded', () => {
            const welcomeModal = document.getElementById('welcome-modal');
            const closeButton = document.querySelector('.close-button');

          
            const isSignedIn = localStorage.getItem('isSignedIn');

            if (isSignedIn === 'true') {
                
                welcomeModal.style.display = 'flex';
                
                localStorage.removeItem('isSignedIn');
            }

            closeButton.addEventListener('click', () => {
                welcomeModal.style.display = 'none';
            });

            window.addEventListener('click', (event) => {
                if (event.target === welcomeModal) {
                    welcomeModal.style.display = 'none';
                }
            });
        });
    </script>

    <footer class="footer">
            <div class="footer-column">
                <h3>UTHM Info</h3>
                <ul>
                    <li><a href="https://www.uthm.edu.my/en/">UTHM Official</a></li>
                    <li><a href="https://www.uthm.edu.my/en/about/overview/leaders-and-management">Top Management</a></li>
                    <li><a href="https://www.uthm.edu.my/en/about/overview/faculty-and-office">Centre and Office</a></li>
                    <li><a href="https://linktr.ee/uthmofficial">About UTHM</a></li>
                    <li><a href="https://www.uthm.edu.my/en/contact-us">Contact us</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h3>Branch</h3>
                <ul>
                    <li><a href="https://pagoh.uthm.edu.my/">UTHM Pagoh Campus</a></li>
                    <li><a href="https://www.uthm.edu.my/en/">UTHM Main Campus</a></li>
                </ul>
                <h3>Building</h3>
                <ul>
                    <li><a href="https://ptta.uthm.edu.my/">Tunku Tun Aminah Library</a></li>
                    <li><a href="https://kolejkediaman.uthm.edu.my/">Pusat Perumahan Pelajar</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h3>Faculty</h3>
                <ul>
                    <li><a href="https://fkaab.uthm.edu.my/">Faculty of Civil Engineering and Built Environment</a></li>
                    <li><a href="https://fkee.uthm.edu.my/">Faculty of Electrical and Electronic Engineering</a></li>
                    <li><a href="https://fkmp.uthm.edu.my/">Faculty of Mechanical and Manufacturing Engineering</a></li>
                    <li><a href="https://ftmb.uthm.edu.my/">Faculty of Technology Management Business</a></li>
                    <li><a href="https://fptv.uthm.edu.my/en/">Faculty of Technical and Vocational Education</a></li>
                    <li><a href="https://fcsit.uthm.edu.my/">Faculty of Computer Science and Information Technology</a></li>
                    <li><a href="https://fast.uthm.edu.my/">Faculty of Applied Science and Technology</a></li>
                    <li><a href="https://ftk.uthm.edu.my/">Faculty of Engineering Technology</a></li>
                </ul>
                <br>
                
            </div>
            <div class="footer-column app-links">
                <h3>Download UTHM INC App</h3>
                <a href="#">
                    <div class="app-link">
                        <i class="fab fa-apple"></i>
                        <div>
                            <span>Download on the</span>
                            <strong>App Store</strong>
                        </div>
                    </div>
                </a>
                <a href="#">
                    <div class="app-link">
                        <i class="fab fa-google-play"></i>
                        <div>
                            <span>Get it on</span>
                            <strong>Google Play</strong>
                        </div>
                    </div>
                </a>
                <br>
                
            </div>
            <div class="footer-column">
                <h3>Connect with UTHM</h3>
                <div class="social-icons">
                    <a href="https://www.instagram.com/uthmjohor?igsh=MWloaW5pbGM0YmI1Mw=="><i class="fab fa-instagram"></i></a>
                    <a href="https://www.facebook.com/uthmjohor/?locale=ms_MY"><i class="fab fa-facebook"></i></a>
                    <a href="https://twitter.com/uthmjohor"><i class="fab fa-twitter"></i></a>
                    <a href="https://www.tiktok.com/@uthmjohor?_t=8n87xAZXos3&_r=1"><i class="fab fa-tiktok"></i></a>
                    <a href="http://www.youtube.com/@UTHMTV"><i class="fab fa-youtube"></i></a>
                </div>
                <br>
                <h3>We accept</h3>
                <div class="payment-methods">
                    <img src="mastercard.jpg" alt="FPX" width="50px" height="30px">
                    <img src="visa.jpg" alt="FPX" width="50px" height="30px">
                    <img src="fpx.png" alt="FPX" width="50px" height="30px">
                    <img src="tng-ewallet.png" alt="Touch N Go" width="50px" height="30px">
                </div>
            </div>
        </footer>
    

    <script>
        // JavaScript for dropdown functionality
        document.querySelector('.dropbtn').addEventListener('click', function() {
            document.querySelector('.dropdown-content').classList.toggle('show');
        });

        // Close the dropdown if the user clicks outside of it
        window.onclick = function(event) {
            if (!event.target.matches('.dropbtn')) {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                for (var i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                        openDropdown.classList.remove('show');
                    }
                }
            }
        }
    </script>

</body>
</html>