
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UTHM INC - Sign Up</title>
    <link rel="icon" type="image/png" href="logo.jpg">
    <img src="signup_image.jpeg" alt="background image" />
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            font-family: 'Roboto', sans-serif;
            font-weight: bold;
            margin-top: 30px;
            
        }

        .container {
            background-color: white;
            padding: 20px;
            padding-right: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            position: relative;
        }

        .container h2 {
            margin-top: 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        td {
            padding: 10px;
            border-bottom: 1px solid #ccc;
        }

        td label {
            font-weight: normal;
        }

        input[type="text"], input[type="password"], input[type="radio"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-top: 5px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .radio-group {
            display: flex;
            align-items: center;
        }

        .submit-button {
            display: flex;
            flex-direction: column;
            gap: 10px;
            width: 100%;
            margin-bottom: 20px;
            margin-top: 20px;
        }

        .submit {
            padding: 10px;
            font-size: 16px;
            color: white;
            border: none;
            text-decoration: none;
            border-radius: 4px;
            cursor: pointer;
            background-color: #007BFF;
            text-align: center;
        }

        .submit:hover {
            background-color: #0056b3;
        }

        .signin-link {
            margin: 10px 0;
            font-size: 16px;
            text-align: center;
        }

        .terms {
            font-size: 12px;
            color: #000000;
            text-align: center;
        }

        .terms a {
            color: #0073bb;
            text-decoration: none;
        }

        .error-message {
            color: red;
            font-size: 14px;
            margin-top: 10px;
            text-align: center;
        }

        img {
            position: absolute;
            inset: 0;
            width: 100%;
            height: 700px;
            z-index: -5;
        }
    </style>
</head>
<body>
<div class="container">
        <h2>Sign Up</h2>
        <form id="signup-form" action="signup.php" method="post">
            <table>
                <tr>
                    <td><label for="username">Username:</label></td>
                    <td><input type="text" id="username" name="username"></td>
                </tr>
                <tr>
                    <td><label for="age">Age:</label></td>
                    <td><input type="text" id="age" name="age"></td>
                </tr>
                <tr>
                    <td><label for="gender">Gender:</label></td>
                    <td>
                        <div class="radio-group">
                            <input type="radio" id="male" name="gender" value="Male">
                            <label for="male">Male</label>
                            <input type="radio" id="female" name="gender" value="Female">
                            <label for="female">Female</label>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td><label for="phoneno">Phone Number:</label></td>
                    <td><input type="text" id="phoneno" name="phoneno"></td>
                </tr>
                <tr>
                    <td><label for="userpassword">Password:</label></td>
                    <td><input type="password" id="userpassword" name="userpassword"></td>
                </tr>
                <tr>
                    <td><label for="confirm-password">Confirm Password:</label></td>
                    <td><input type="password" id="confirm-password" name="confirm-password"></td>
                </tr>
            </table>
            <div class="submit-button">
                <button type="submit" id="submit">Submit</button>
            </div>
            <p class="signin-link">Already a member? <a href="signin.html">Sign in</a></p>
            <p class="terms">By signing up, you agree to our <a href="terms.html">Terms of Service</a> and <a href="policy.html">Privacy Policy</a>.</p>
        </form>
        <p id="error-message" class="error-message"></p>
    </div>
    

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            console.log("Welcome to the registration page!");

            const form = document.getElementById('signup-form');
            const errorMessage = document.getElementById('error-message');

            form.addEventListener('submit', (event) => {
                const username = document.getElementById('username').value;
                const age = document.getElementById('age').value;
                const gender = document.querySelector('input[name="gender"]:checked');
                const phoneno = document.getElementById('phoneno').value;
                const userpassword = document.getElementById('userpassword').value;
                const confirmPassword = document.getElementById('confirm-password').value;

                if (!username || !age || !gender || !phoneno || !userpassword || !confirmPassword) {
                    event.preventDefault();
                    errorMessage.textContent = "Please fill in all fields.";
                } else if (userpassword !== confirmPassword) {
                    event.preventDefault();
                    errorMessage.textContent = "Passwords do not match.";
                }
            });
        });
    </script>
</body>
</html>


<?php
// Database connection settings
$servername = "127.0.0.1";
$username = "u489039624_G10";
$password = "webBIT21503";
$dbname = "u489039624_G10";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $phoneno = $_POST['phoneno'];
    $userpassword = $_POST['userpassword'];
    $confirm_password = $_POST['confirm-password'];

    // Validate inputs
    if (empty($username) || empty($age) || empty($gender) || empty($phoneno) || empty($userpassword) || $userpassword != $confirm_password) {
        echo "<script>alert('Please fill in all fields correctly.'); window.history.back();</script>";
    } else {
        // Hash the password
        $hashed_password = password_hash($userpassword, PASSWORD_DEFAULT);

        // Insert data into database
        $sql = "INSERT INTO users (username, age, gender, phoneno, userpassword) VALUES ('$username', '$age', '$gender', '$phoneno', '$hashed_password')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Registration successful!'); window.location.href = 'signin.html';</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>