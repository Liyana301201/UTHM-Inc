<?php
session_start();
// Database connection settings
$servername = "127.0.0.1";
$username = "u489039624_G10";
$password = "webBIT21503";
$dbname = "u489039624_G10";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $current_password = $_POST['current-password'];
    $new_password = $_POST['new-password'];
    $confirm_password = $_POST['confirm-password'];
    $user_id = $_SESSION['user_id']; // Assuming user_id is stored in session after login

    // Fetch current password from database
    $sql = "SELECT password FROM users WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($hashed_password);
    $stmt->fetch();

    if (password_verify($current_password, $hashed_password)) {
        if ($new_password === $confirm_password) {
            if (preg_match('/^(?=.*[a-z])(?=.*[A-Z]).{8,16}$/', $new_password)) {
                // Hash new password
                $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

                // Update password in database
                $sql = "UPDATE users SET password=? WHERE id=?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("si", $new_hashed_password, $user_id);
                if ($stmt->execute()) {
                    echo "Password changed successfully!";
                } else {
                    echo "Error updating password: " . $conn->error;
                }
            } else {
                echo "New password does not meet the requirements.";
            }
        } else {
            echo "New password and confirm password do not match.";
        }
    } else {
        echo "Current password is incorrect.";
    }

    $stmt->close();
}

$conn->close();
?>
