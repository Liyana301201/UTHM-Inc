/* function to dropdown */
function toggleDropdown() {
    document.getElementById("dropdownContent").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
        var dropdowns = document.getElementsByClassName("dropdown-content");
        for (var i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
}

function toggleDropdown() {
    document.getElementById("dropdownContent").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
        var dropdowns = document.getElementsByClassName("dropdown-content");
        for (var i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
}

// Simulate getting user data after login
function setUser(user) {
    document.getElementById('userAvatar').src = user.avatarUrl;
    document.getElementById('username').textContent = user.username;
}

// Example user data
const user = {
    username: 'username',
    avatarUrl: 'avatar.png'
};

// Set user data on page load or after login
window.onload = function() {
    setUser(user);
};

// JavaScript functions for logout modal
function showLogoutModal() {
    var modal = document.getElementById('logoutModal');
    modal.style.display = 'block';
}

function closeLogoutModal() {
    var modal = document.getElementById('logoutModal');
    modal.style.display = 'none';
}

function confirmLogout() {
    // Add code here to perform logout actions
    alert('You have been logged out.');
    closeLogoutModal(); // Close the modal after logout
}

// JavaScript functionality can be expanded as needed

document.addEventListener("DOMContentLoaded", function() {
    // Example function to handle adding new card
    document.querySelectorAll(".add-card-btn").forEach(button => {
        button.addEventListener("click", function() {
            alert("Add card functionality goes here.");
        });
    });
});

/* Function to calculate the price of product */
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Function to update the cart summary
function updateSummary() {
    const summaryDiv = document.getElementById('orderSummary');
    const totalDiv = document.getElementById('total');
    summaryDiv.innerHTML = '';
    let total = 0;
    let totalQuantity = 0;

    cart.forEach((product, index) => {
        const productTotal = product.price * product.quantity;
        total += productTotal;
        totalQuantity += product.quantity;

        const productDiv = createProductDiv(product, index);
        summaryDiv.appendChild(productDiv);
    });

    const { discount, postageFee, finalPrice } = calculatePrice(total, totalQuantity);

    totalDiv.innerHTML = `
    <div class="discount">
        <span>Discount:</span>
        <span>RM${discount.toFixed(2)}</span>
    </div>
    <div class="postage-fee">
        <span>Postage Fee:</span>
        <span>RM${postageFee.toFixed(2)}</span>
    </div>
    <div class="total">
        Total: RM${finalPrice.toFixed(2)}
    </div>
`

}

// Function to create a product div for the summary
function createProductDiv(product, index) {
    const productDiv = document.createElement('div');
    productDiv.classList.add('product-summary');
    productDiv.innerHTML = `
        <input type="checkbox" class="product-checkbox" onchange="calculateTotal()">
        <img src="${product.image}" alt="${product.title}" class="product-image">
        <div>${product.title}</div>
        <div>RM${product.price.toFixed(2)}</div>
        <div class="quantity-controls">
            <button onclick="updateQuantity(${index}, ${product.quantity - 1})">-</button>
            <span>${product.quantity}</span>
            <button onclick="updateQuantity(${index}, ${product.quantity + 1})">+</button>
        </div>
        <div>RM${(product.price * product.quantity).toFixed(2)}</div>
        <button class="delete-btn" onclick="removeFromCart(${index})">Delete</button>
    `;
    return productDiv;
}

// Function to update quantity of a product in the cart
function updateQuantity(index, quantity) {
    if (quantity <= 0) return;
    cart[index].quantity = quantity;
    localStorage.setItem('cart', JSON.stringify(cart));
    updateSummary();
}

// Function to remove a product from the cart
function removeFromCart(index) {
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateSummary();
}

// Function to calculate total price, discount, and postage fee
function calculatePrice(total, totalQuantity) {
    let discount = 0;
    if (totalQuantity >= 5 && totalQuantity <= 10) {
        discount = 0.05 * total;
    } else if (totalQuantity > 10) {
        discount = 0.15 * total;
    }

    total -= discount;

    let postageFee = 0;
    if (total <= 100) {
        postageFee = 10;
    }

    const finalPrice = total + postageFee;

    return { discount, postageFee, finalPrice };
}

// Function to handle checkout process
function checkout() {
    // Handle checkout process
    alert('Proceeding to checkout');
}

// Call updateSummary on window load
window.onload = updateSummary;

function filterProducts() {
    var checkboxes = document.querySelectorAll('.sidebar input[type="checkbox"]');
    var products = document.querySelectorAll('.product');
    var selectedCategories = Array.from(checkboxes).filter(checkbox => checkbox.checked).map(checkbox => checkbox.value);

    products.forEach(product => {
      var productCategory = product.getAttribute('data-category');
      if (selectedCategories.length === 0 || selectedCategories.includes(productCategory)) {
        product.style.display = 'block';
      } else {
        product.style.display = 'none';
      }
    });
  }

  function handleSearch(event) {
    if (event.key === 'Enter') {
      event.preventDefault();
      var searchKeyword = document.getElementById('searchText').value.toLowerCase();
      var products = document.querySelectorAll('.product');

      products.forEach(product => {
        var title = product.querySelector('.product-title').textContent.toLowerCase();
        var description = product.querySelector('.product-description').textContent.toLowerCase();
        if (title.includes(searchKeyword) || description.includes(searchKeyword)) {
          product.style.display = 'block';
        } else {
          product.style.display = 'none';
        }
      });
    }
  }

  function toggleDropdown() {
    var dropdownContent = document.getElementById('dropdownContent');
    dropdownContent.style.display = dropdownContent.style.display === 'block' ? 'none' : 'block';
  }

  function showLogoutModal() {
    alert('You have been logged out.');
  }

  //handle the page account
    document.addEventListener("DOMContentLoaded", function() {
        var navItems = document.querySelectorAll(".nav-item a");

        navItems.forEach(function(item) {
            item.addEventListener("click", function() {
                navItems.forEach(function(nav) {
                    nav.parentElement.classList.remove("active");
                });
                this.parentElement.classList.add("active");
            });
        });
    });

