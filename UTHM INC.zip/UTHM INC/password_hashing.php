<?php
// Include database connection file
include_once('database_connection.php');

if (isset($_POST['register'])) {
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $userpassword = password_hash($_POST['userpassword'], PASSWORD_BCRYPT); // Hash the password

    if ($username != "" && $userpassword != "") {
        $sql_query = "INSERT INTO signin (username, userpassword) VALUES (?, ?)";
        $stmt = $con->prepare($sql_query);
        $stmt->bind_param("ss", $username, $userpassword);

        if ($stmt->execute()) {
            echo "User registered successfully";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Username and password cannot be empty";
    }
}
?>
