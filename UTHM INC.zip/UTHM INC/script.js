function changeQuantity(button, change) {
    const quantityInput = button.parentElement.querySelector('.quantity-input');
    let quantity = parseInt(quantityInput.value);
    quantity += change;

    if (quantity < 1) quantity = 1;

    quantityInput.value = quantity;

    const itemPriceElement = button.parentElement.previousElementSibling;
    const itemPrice = parseFloat(itemPriceElement.textContent.substring(2));
    
    const itemTotalPriceElement = button.parentElement.nextElementSibling;
    const itemTotalPrice = (itemPrice * quantity).toFixed(2);
    
    itemTotalPriceElement.textContent = 'RM' + itemTotalPrice;

    updateCartTotal();
}

function updateCartTotal() {
    const itemTotalPrices = document.querySelectorAll('.item-total-price');
    let cartTotal = 0;
    
    itemTotalPrices.forEach(itemTotalPriceElement => {
        const itemTotalPrice = parseFloat(itemTotalPriceElement.textContent.substring(2));
        cartTotal += itemTotalPrice;
    });
    
    document.getElementById('cart-total-price').textContent = 'RM' + cartTotal.toFixed(2);
}

function changeImage(thumbnail) {
    const mainImage = document.getElementById('main-image');
    mainImage.src = thumbnail.src;
}

function selectColor(color) {
    alert('Color selected: ' + color);
}

function changeQuantity(change) {
    const quantityInput = document.getElementById('quantity');
    let quantity = parseInt(quantityInput.value);
    quantity += change;
    if (quantity < 1) quantity = 1;
    quantityInput.value = quantity;
}

function addToCart() {
    const quantity = document.getElementById('quantity').value;
    alert(quantity + ' items added to cart');
}

function buyNow() {
    const quantity = document.getElementById('quantity').value;
    alert('Buying ' + quantity + ' items now');
}
