const productList = document.getElementById('productList');
const searchBar = document.getElementById('searchBar');
let UTHMprod = [];

// Get the button
let mybutton = document.getElementById("myBtn");
 
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}
// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
//source: w3school.com

searchBar.addEventListener('keyup', (e) => {
    const searchString = e.target.value.toLowerCase();

    const filteredproduct = UTHMprod.filter((product) => {
        return (
            product.name.toLowerCase().includes(searchString) ||
            product.type.toLowerCase().includes(searchString)
        );
    });
    displayproduct(filteredproduct);
});

const loadproduct = async () => {
    try {
        const res = await fetch('jersey.json');
        UTHMprod = await res.json();
        displayproduct(UTHMprod);
    } catch (err) {
        console.error(err);
    }
};

const displayproduct = (products) => {
    const htmlString = products
        .map((product) => {
            return `
            <li class="product">
                <a href=${product.link}><img style="box-shadow: 10px 10px 5px gray;" src="${product.image}"></img></a>
                <h2>${product.name}</h2>
                <p>RM${product.price}</p>
            </li>
        `;
        })
        .join('');
    productList.innerHTML = htmlString;
};

loadproduct();


//dropdown category under search bar
let dropdownBtn = document.getElementById("drop-text");
let list = document.getElementById("list");
let icon = document.getElementById("icon");
let span = document.getElementById("span");

//show dropdown list
dropdownBtn.onclick =function(){
    //rotate arrow
    if(list.classList.contains('show')){
        icon.style.rotate = "0deg";
    }else{
        icon.style.rotate = "-180deg";
    }
    list.classList.toggle("show");
};

//hide dropdown
window.onclick = function(e){
    if(
        e.target.id !== "drop-text" &&
        e.target.id !== "span" &&
        e.target.id !== "icon"
    ){
        list.classList.remove("show");

        icon.style.rotate = "0deg";
    }
};