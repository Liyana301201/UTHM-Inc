<?php
// Start session at the very beginning
session_start();

// Database connection settings
$servername = "127.0.0.1";
$username = "u489039624_G10";
$password = "webBIT21503";
$dbname = "u489039624_G10";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

if (isset($_POST['username']) && isset($_POST['userpassword'])) {
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $userpassword = $_POST['userpassword']; // Not escaping password as it will be hashed

    if ($username != "" && $userpassword != "") {
        $sql_query = "SELECT username, userpassword FROM signin WHERE username=?";
        $stmt = $con->prepare($sql_query);
        if ($stmt === false) {
            die('Prepare failed: ' . $con->error);
        }
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($db_username, $db_password_hash);
            $stmt->fetch();
            
            if (password_verify($userpassword, $db_password_hash)) {
                $_SESSION['username'] = $username;
                echo "Login successful";
            } else {
                echo "Invalid username or password";
            }
        } else {
            echo "Invalid username or password";
        }

        $stmt->close();
    } else {
        echo "Username and password cannot be empty";
    }
}

$con->close();

